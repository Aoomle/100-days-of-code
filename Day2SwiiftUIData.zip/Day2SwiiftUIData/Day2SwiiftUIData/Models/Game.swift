//
//  Game.swift
//  Day2SwiiftUIData
//
//  Created by Abdulmalik Muhammad on 29/01/2021.
//

import Foundation

struct Game {
  var target = 50
  var score = 0
  var round = 1
  
  func points(sliderValue: Int) -> Int {
    999
  }
}
